'''
Not even sure I need this
'''

def main():
    print("Synutils is initialized!")


if __name__ == "__main__":
    main()